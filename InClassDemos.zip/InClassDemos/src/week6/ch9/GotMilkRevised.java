package week6.ch9;

/**
 * Replaces Listings 9.1-9.8
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class GotMilkRevised extends GotMilk
{
    private Scanner keyboard;
    private int donutCount, milkCount;

    public static void main (String [] args) {
        GotMilk gm = new GotMilkRevised();
//        gm.demo98a();
//        gm.demo98b();
    }

    public GotMilkRevised()
    {
        super();
    }

    /**
     * Notice the body of this method does not catch exceptions, it just throws them
     * @throws NoMilkException
     */
    private void calcMilkPerDonut() throws NoMilkException
    {
        if (milkCount < 1)
            throw new NoMilkException(); // Notice exception type

        printCalc();
    }


    private void demo98a() {
        System.out.println("##### DEMO 9.8A #####");
        try {
            getData();
            calcMilkPerDonut();

        } catch (NoMilkException e) { // notice exception type
            System.out.println(e.getMessage());
            System.out.println("Go buy some milk.");
        } catch (Exception e) { // catches ANY type of Exception, if it hasn't already been caught
            // Including InputMisMatch
            System.out.println("An error occurred:");
            System.out.println(e.getMessage());
        }
    }

    private void demo98b() {
        System.out.println("##### DEMO 9.8B #####");
        try {
            getData();
            calcMilkPerDonut();

        } catch (NoMilkException e) {
            System.out.println(e.getMessage());
            System.out.println("Go buy some milk.");
        } catch (InputMismatchException e) {
            System.out.println("Hey listen up dummy! Only enter integers!");
            demo98b(); // re-run the system
        } catch (Exception e) { // catches ANY type of Exception, if it hasn't already been caught
            // Including
            System.out.println("An error occurred:");
            System.out.println(e.getMessage());
        }
    }

}