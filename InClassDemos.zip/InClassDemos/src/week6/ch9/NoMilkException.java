package week6.ch9;

/**
 * Modified version of 9.5
 */
public class NoMilkException extends Exception {

    public NoMilkException ()
    {
        super ("But there's no milk!");
    }


    public NoMilkException (String message)
    {
        super (message);
    }
}
