package week6.ch9;

/**
 * Replaces Listings 9.1-9.7
 */

import java.util.Scanner;

public class GotMilk
{
    private Scanner keyboard;
    private int donutCount, milkCount;

    public static void main (String [] args) {
        GotMilk gm = new GotMilk();
//        gm.demo91();
//        gm.demo92();
//        gm.demo97();
    }

    public GotMilk()
    {
        donutCount = 0;
        milkCount = 0;
        keyboard = new Scanner(System.in);
    }

    protected void getData()
    {
        System.out.println ("Enter number of donuts:");
        donutCount = keyboard.nextInt ();
        System.out.println ("Enter number of glasses of milk:");
        milkCount = keyboard.nextInt ();
    }

    protected void printCalc()
    {
        double donutsPerGlass = donutCount / (double) milkCount;
        System.out.println (donutCount + " donuts.");
        System.out.println (milkCount + " glasses of milk.");
        System.out.println ("You have " + donutsPerGlass +
                " donuts for each glass of milk.");
    }

    /**
     * Demonstrates a basic conditional without using exceptions
     */
    private void demo91() {
        System.out.println("##### DEMO 9.1 #####");

        getData();

        //Dealing with an unusual event without Javas exception
        //handling features:
        if (milkCount < 1)
        {
            System.out.println ("No milk!");
            System.out.println ("Go buy some milk.");
        }
        else
        {
            printCalc();
        }
        System.out.println ("End of program.");
    }

    /**
     * Replaces 9.1 with a basic Exception throw
     */
    private void demo92()
    {
        System.out.println("##### DEMO 9.2 #####");
        try
        {
            getData();
            if (milkCount < 1)
                throw new Exception ("Exception: No milk!");

            printCalc();
        }
        catch (Exception e)
        {
            System.out.println (e.getMessage ());
            System.out.println ("Go buy some milk.");
        }
        System.out.println ("End of program.");
    }

    private void demo97() {
        System.out.println("##### DEMO 9.7 #####");
        try {
            getData();

            if (milkCount < 1)
                throw new NoMilkException(); // Notice exception type

            printCalc();

        } catch (NoMilkException e) { // notice exception type
            System.out.println(e.getMessage());
            System.out.println("Go buy some milk.");
        }
    }
}