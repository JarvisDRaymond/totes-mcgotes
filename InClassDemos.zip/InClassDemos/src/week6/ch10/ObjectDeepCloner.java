package week6.ch10;

/**
 * An object deep cloner using serialization
 * Modified version of:
 * @source http://www.javaworld.com/article/2077578/learn-java/java-tip-76--an-alternative-to-the-deep-copy-technique.html
 */

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectDeepCloner
{
    // so that nobody can accidentally create an ObjectDeepCloner object
    private ObjectDeepCloner(){}

    // returns a deep copy of an object
    static public Object deepCopy(Object oldObj)
    {
        ObjectOutputStream oos;
        ObjectInputStream ois;
        Object clone = null;

        try
        {
            ByteArrayOutputStream bos =
                    new ByteArrayOutputStream(); // A
            oos = new ObjectOutputStream(bos); // B
            // serialize and pass the object
            oos.writeObject(oldObj);   // C
            oos.flush();               // D
            ByteArrayInputStream bin =
                    new ByteArrayInputStream(bos.toByteArray()); // E
            ois = new ObjectInputStream(bin);                  // F
            // return the new object

            oos.close();
            ois.close();
            clone = ois.readObject(); // G
        }
        catch(Exception e)
        {
            System.out.println("Exception in ObjectCloner");
            System.out.println(e.getMessage());
        }

//        try {
//            oos.close();
//            ois.close();
//        } catch (Exception e) {
//            System.out.println("Java could not close the input or output stream: " + e.getMessage());
//        }

        return clone;
    }

}
