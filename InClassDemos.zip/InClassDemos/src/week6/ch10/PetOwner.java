package week6.ch10;

import java.io.Serializable;

/**
 * Replaces listing 6.18
 */
public class PetOwner implements Serializable {
    private Pet thePet;

    public PetOwner(Pet thePet)
    {
        this.thePet = thePet;
    }

    public Pet getPet()
    {
        Pet p = (Pet) ObjectDeepCloner.deepCopy(thePet);
        return p;
    }
}
