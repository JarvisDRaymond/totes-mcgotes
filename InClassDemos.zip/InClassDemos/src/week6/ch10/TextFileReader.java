package week6.ch10;

/**
 * Replaces listing 10.2
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class TextFileReader
{
    private Scanner inputStream;
    private String filename;

    /**
     * Boots up the application
     * @param args pass the filename as the first argument
     */
    public static void main (String [] args) {
        String filename;
        if (args.length < 1) {
            filename = "text-files" + File.separator + "in.txt";
            System.out.println("Notice: No filename specified by user. Using default file: " + filename);
        } else {
            filename = args[0];
        }

        (new TextFileReader(filename)).run();
    }

    public TextFileReader(String filename) {
        this.filename = filename;
        initReader();
    }

    /**
     * Starts the Scanner and opens a file for reading
     */
    private void initReader()
    {
        System.out.print("Opening " + filename + " for reading...");
        try
        {
            inputStream = new Scanner (new File (filename));
        }
        catch (FileNotFoundException e)
        {
            System.out.print ("Error opening the file " +
                    filename);
            System.exit (1);
        }
        System.out.println("...file opened OK.");
    }

    /**
     * Closes Java's connection to filename
     */
    private void closeReader() {
        inputStream.close();
        System.out.println("Closed file " + filename);
    }

    /**
     * Executes the application
     */
    public void run() {
        printData();
        closeReader();
    }

    /**
     * Writes the data to the terminal
     */
    private void printData() {
        System.out.println(filename + " reads as follows:\n");
        while (inputStream.hasNextLine ())
        {
            String line = inputStream.nextLine ();
            System.out.println ("\t" + line);
        }

        System.out.println("\nDone reading from " + filename);
    }

}