package week6.ch10;

/**
 * Replaces listing 10.1
 */

import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class TextFileWriter
{
    private PrintWriter writer;
    private Scanner keyboard;
    private String filename;

    /**
     * Boots up the application
     * @param args pass the filename as the first argument
     */
    public static void main (String [] args) {
        String filename;
        if (args.length < 1) {
            filename = "text-files" + File.separator + "out.txt";
            System.out.println("Notice: No filename specified by user. Using default file: " + filename);
        } else {
            filename = args[0];
        }

        (new TextFileWriter(filename)).run();
    }

    public TextFileWriter(String filename) {
        this.filename = filename;
        initKeyboard();
        initWriter();
    }

    /**
     * Connects Java to the user keyboard
     */
    private void initKeyboard()
    {
        keyboard = new Scanner(System.in);
    }

    /**
     * Starts the PrintWriter and opens a file for writing
     */
    private void initWriter()
    {
        System.out.print("Opening " + filename + " for writing...");
        try
        {
            writer = new PrintWriter (filename);
        }
        catch (FileNotFoundException e)
        {
            System.out.print ("Error opening the file " +
                    filename);
            System.exit (1);
        }
        System.out.println("...file opened OK.");
    }

    /**
     * Closes Java's connection to filename
     */
    private void closeWriter() {
        writer.close();
        System.out.println("Closed file " + filename);
    }

    /**
     * Executes the application
     */
    public void run() {
        writeData(getInput());
        closeWriter();
    }

    /**
     * Writes the data to file
     * @param data the data to write
     */
    private void writeData(String[] data) {
        System.out.print("Writing data to " + filename + "...");
        for(String line : data)
            writer.println(line);
        System.out.println("done!");
    }

    /**
     * Prompts the user for 3 lines of input
     * @return The user input
     */
    private String[] getInput() {
        String[] input = new String[3];
        System.out.println("Enter 3 lines of data:");
        for (int i = 0; i < 3; i++) {
            input[i] = keyboard.nextLine();
        }
        return input;
    }
}