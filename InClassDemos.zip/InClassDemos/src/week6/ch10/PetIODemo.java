package week6.ch10;

import java.io.*;

/**
 * Demonstrates saving objects to binary files
 */
public class PetIODemo {

    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    private String filename;

    public static void main (String [] args) {
        String filename;
        if (args.length < 1) {
            filename = "binary-files" + File.separator + "pets.dat";
            System.out.println("Notice: No filename specified by user. Using default file: " + filename);
        } else {
            filename = args[0];
        }

//        (new PetIODemo(filename)).run();
        (new PetIODemo(filename)).runWithChanges();
    }

    public PetIODemo(String filename) {
        this.filename = filename;
        initOutputStream();
    }

    public void run() {
        Pet tom = new  Pet("Tom", 8, 12.4);
        Pet jerry = new Pet ("Jerry", 2, 1.3);
        writePetToFile(tom);
        writePetToFile(jerry);
        closeStream(outputStream);
        initInputStream();
        printPets(readPetsFromFile());
        closeStream(inputStream);
    }

    public void runWithChanges() {
        Pet tom = new  Pet("Tom", 8, 12.4);
        Pet jerry = new Pet ("Jerry", 2, 1.3);
        writePetToFile(tom);
        writePetToFile(jerry);

        System.out.println("Now changing Tom to Sylvester:");
        tom.setName("Sylvester");
        tom.setAge(23);
        tom.setWeight(47.23);
        tom.writeOutput();

        closeStream(outputStream);
        initInputStream();
        printPets(readPetsFromFile());
        closeStream(inputStream);
    }

    private void initOutputStream() {
        try {
            outputStream = new ObjectOutputStream(
                    new FileOutputStream(filename)
            );
        } catch (IOException e) {
            System.out.println("Error opening output file " +
                    filename + ".");
            System.exit(0);
        }
    }

    private void writePetToFile(Pet p) {
        System.out.print("Writing pet " + p.getName() + " to file " +
                filename + "...");
        try {
            outputStream.writeObject(p);
        } catch (IOException e) {
            System.out.println("Error writing to file " +
                    filename + ".");
            System.exit(1);
        }
        System.out.println("Done!");
    }

    private void closeStream(ObjectOutputStream s)
    {
        try {
            s.close();
        } catch (Exception e) {
            System.out.println("Java could not close the output stream: " + e);
        }
    }

    private void closeStream(ObjectInputStream s)
    {
        try {
            s.close();
        } catch (Exception e) {
            System.out.println("Java could not close the input stream: " + e);
        }
    }

    private void initInputStream() {
        System.out.print("Opening file " + filename + " for reading...");
        try {
            inputStream = new ObjectInputStream(
                    new FileInputStream(filename)
            );
        } catch (IOException e) {
            System.out.println("Error opening input file " +
                    filename + ".");
            System.exit(1);
        }
        System.out.println("Done!");

    }

    private Pet[] readPetsFromFile() {
        Pet[] pets = new Pet[2];
        try {
            pets[0] = (Pet) inputStream.readObject();
            pets[1] = (Pet) inputStream.readObject();
        } catch (Exception e) {
            System.out.println("Error reading from file " +
                    filename + ".");
            System.exit(0);
        }
        return pets;
    }

    private void printPets(Pet[] pets) {
        System.out.println("The following pets were read from file: ");
        for(Pet p : pets)
            p.writeOutput();
    }
}