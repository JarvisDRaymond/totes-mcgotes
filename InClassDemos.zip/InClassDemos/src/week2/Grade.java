package week2;

import java.util.Scanner;

public class Grade {
    public static void main(String[] args) {
        char gradeGood, gradeBad;
        int score;
        Scanner sc = new Scanner(System.in);
        while(true) {
            System.out.print("Enter a score 0-100: ");
            score = sc.nextInt();

            // correctly calculate the grade
            if (score >= 90)
                gradeGood = 'A';
            else if (score >= 80)
                gradeGood = 'B';
            else if (score >= 70)
                gradeGood = 'C';
            else if (score >= 60)
                gradeGood = 'D';
            else
                gradeGood = 'F';

            // incorrectly calculate the grade
            if (score > 59)
                gradeBad = 'D';
            else if (score > 69)
                gradeBad = 'C';
            else if (score > 79)
                gradeBad = 'B';
            else if (score > 89)
                gradeBad = 'A';
            else
                gradeBad = 'F';

            System.out.println("Grades:");
            System.out.println("Good: " + gradeGood);
            System.out.println("Bad:  " + gradeBad);
        }
    }
}