package week2;

/**
 * Created by elly-luc on 6/15/17.
 */
public class ForScope {

    public static void main(String[] args) {
        int sum, n;

        sum = 1;
        for (n = 1; n < 5; n++) {
            sum *= n; // sum = sum * n;
        }

        System.out.println("Value of sum: " + sum);
        System.out.println("Value of n  : " + n);

//        int sum2;
//
//        sum2 = 1;
//        for (int n2 = 1; n2 < 5; n2++) {
//            sum2 *= n2;
//
//        }
//        System.out.println("Value of sum2: " + sum2);
//        System.out.println("Value of n2  : " + n2);
//
//        int sum3, n3;
//
//        for (
//            n3 = 1, sum3 = 7;
//            n3 < 5 && n3 > n || n3 != 0;
//            sum3*=n3, n3++
//        );
    }
}
