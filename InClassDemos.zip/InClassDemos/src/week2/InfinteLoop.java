package week2;

/**
 * Created by elly-luc on 6/15/17.
 */
public class InfinteLoop {
    public static void main(String[] args) {
        int count = 0;
        while(true) {
            System.out.println(count++);
        }
    }
}
