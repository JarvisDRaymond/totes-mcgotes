package week2;

public class While {
    public static void main(String[] args) {

        int count;

        System.out.println("#############");
        System.out.println("WHILE LOOP DEMO:");
        count = 0;
        while (count < 5) {
            System.out.println(++count);
        }

        System.out.println("\n\n#############");
        System.out.println("DO WHILE LOOP DEMO:");
        count = 0;
        do {
            System.out.println(++count);
        } while (count < 5);
    }
}