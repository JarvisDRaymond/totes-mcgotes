package week1;

import java.util.Scanner;

public class EggBasket
{
    public static void main (String [] args)
    {
        Scanner keyboard = new Scanner(System.in);

        int numberOfBaskets, eggsPerBasket, totalEggs;

        System.out.print("How many eggs per basket? ");
        eggsPerBasket = keyboard.nextInt();
        // eggsPerBasket = 3;   // 00000011

        numberOfBaskets = 5; // 00000101
        totalEggs = numberOfBaskets * eggsPerBasket;
        System.out.println ("If you have");
        System.out.println (eggsPerBasket + " eggs per basket and");
        System.out.println (numberOfBaskets + " baskets, then");
        System.out.println ("the total number of eggs is " + totalEggs);
    }
}