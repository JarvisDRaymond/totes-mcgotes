package week3;

/**
 * Created by elly-luc on 6/22/17.
 */
public class Text {

    private String title;
    private String author;
    private String publisherDate;
    private String publisher;
    private String content;
    private String copyrightDate; // YYYY-MM-DD



    // check for equality
    public boolean equals(Text otherText) {

        if (this == otherText) return true;

        return
            (this.getTitle().equalsIgnoreCase(otherText.getTitle()) &&
            this.getPublisher().equalsIgnoreCase(otherText.getPublisher()) &&
            this.getAuthor().equalsIgnoreCase(otherText.getAuthor()));
    }


    public String getCopyrightDate() {
        return copyrightDate;
    }

    public void setCopyrightDate(String c) {
        copyrightDate = c;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisherDate() {
        return publisherDate;
    }

    public void setPublisherDate(String publisherDate) {
        this.publisherDate = publisherDate;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
