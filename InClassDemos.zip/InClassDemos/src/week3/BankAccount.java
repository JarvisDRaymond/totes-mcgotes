package week3;

/**
 * Listing 5.5A (7th Ed)
 */
public class BankAccount
{
    public double amount;
    public double rate;
    public void showNewBalance ()
    {
        double newAmount = amount + (rate / 100.0) * amount;
        System.out.println ("With interest added, the new amount is $" +
                newAmount);
    }
}