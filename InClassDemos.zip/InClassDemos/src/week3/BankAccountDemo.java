package week3;

/**
 * Listing 5.5B (7th Ed)
 */
public class BankAccountDemo {
    public static void main (String [] args)
    {
        BankAccount myAccount = new BankAccount ();
        myAccount.amount = 100.00;
        myAccount.rate = 5;
        double newAmount = 800.00; // this is a different var than BankAccount.newAmount
        myAccount.showNewBalance ();
        System.out.println ("I wish my new amount were $" + newAmount);
    }
}
