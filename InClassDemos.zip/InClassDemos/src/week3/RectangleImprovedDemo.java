package week3;

/**
 * Replaces Listing 5.16
 */
public class RectangleImprovedDemo {
    public static void main(String[] args) {
        RectangleImproved box = new RectangleImproved();
        box.setDimensions(5, 3);
//        printArea(); // students: doesn't work - why?
        box.printArea(); // the correct approach
    }
}