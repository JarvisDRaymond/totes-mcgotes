package week3;

/**
 * Created by elly-luc on 6/22/17.
 */
public class TextDemo {

    public static void main(String[] args) {
        Text t1, t2;
        t1 = new Text();
        t2 = new Text();

        t1.setTitle("Text 1");
        t1.setAuthor("Author 1");
        t1.setPublisher("Publisher 1");

        t2.setTitle("Text 1");
        t2.setAuthor("Author 1");
        t2.setPublisher("Publisher 1");

        if (t1.equals(t2)) {
            System.out.println("Texts are equal");
        } else {
            System.out.println("Texts unequal");
        }
    }
}
