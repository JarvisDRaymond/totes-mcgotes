package week3;

/**
 * Variation of Listings 5.9 & 5.10 (7th Ed)
 */
public class Rectangle {
    private int width;
    private int height;

    public void setDimensions (int newWidth, int newHeight)
    {
        width = newWidth;
        height = newHeight;
    }


    public int getArea ()
    {
        return width * height;
    }
}
