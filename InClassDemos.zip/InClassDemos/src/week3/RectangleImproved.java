package week3;

/**
 * Represents a Rectangle
 * Replaces Listing 5.13 and 5.14 and 5.15
 */
public class RectangleImproved {

    private int width = 0;
    private int height = 0;

    /**
     * Sets the dimensions for the rectangle
     * preconditions: none
     * postconditions: the dimensions have been set
     * @param newWidth an integer greater than -1
     * @param newHeight an integer greater than -1
     */
    public void setDimensions (int newWidth, int newHeight)
    {
        if (newWidth < 0) {
            System.out.println("Width must be >= 0");
            return;
        }

        if (newHeight < 0) {
            System.out.println("Height must be >= 0");
            return;
        }

        width = newWidth;
        height = newHeight;
    }


    /**
     * Calculates the rect area
     * preconditions: width and height have been set
     * @return the width * height
     */
    public int getArea ()
    {
        return width * height;
    }

    /**
     * Prints to screen the area
     * preconditions: width and height have been set
     * postconditions: the area is printed to the terminal
     */
    public void printArea()
    {
        System.out.println("The area is: " + getArea());
        // Or
        // System.out.println("The area is: " + this.getArea());
    }
}
