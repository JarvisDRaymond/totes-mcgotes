package week5.ch8;

/**
 * Listing 8.3
 */
public class InheritanceDemo
{
    public static void main (String [] args)
    {
        Student s = new Student ();
        s.setName ("Warren Peace");
        s.setStudentNumber (1234);
        s.writeOutput ();
    }
}