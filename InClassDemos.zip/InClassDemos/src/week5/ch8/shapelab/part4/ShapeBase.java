package week5.ch8.shapelab.part4;

/**
 * An abstract class representing the shared
 * methods between all shapes
 */
abstract class ShapeBase implements Shape {
    protected int id;

    /**
     * Determines if 2 shapes are equal
     * 2 shapes are equal if and only if they have
     * the same type, same area, and same dimensions
     * SHAPE ID DOES NOT MATTER FOR EQUALITY!
     */
//    @Override
//    public boolean equals(...)
//    {
//        return ...;
//    }

      // @todo
//    @Override
//    public String toString()
//    {
//        return getType() + "(ID: " + getId() + ")";
//    }
}
