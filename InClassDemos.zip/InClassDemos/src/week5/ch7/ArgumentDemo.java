package week5.ch7;

/**
 * Replaces Listing 7.5
 * A demonstration of using indexed variables as arguments.
 */
public class ArgumentDemo
{
    public static void main (String [] args)
    {
        int[] scores = {5, 8};
        double average = getAverage(scores[0], scores[1]);
        System.out.println("The average values is: " + average);

//        System.out.println("\nThe array doubled is:");
//        scores = doubleEach(scores);
//        System.out.print("[");
//        for (int s : scores)
//            System.out.print(s + " ");
//        System.out.println("]");
    }


    public static double getAverage (int n1, int n2)
    {
        return (n1 + n2) / 2.0;
    }

//    public static int[] doubleEach(int[] scores)
//    {
//        for(int i = 0; i < scores.length; i++)
//            scores[i] *= 2;
//
//        return scores;
//    }
}