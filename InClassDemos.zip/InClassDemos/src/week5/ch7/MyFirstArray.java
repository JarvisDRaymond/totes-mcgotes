package week5.ch7;

/**
 * Replaces 7.1
 */
public class MyFirstArray {
    public static void main(String[] args)
    {
        // create an array of 5 integers
        int[] theArray = new int[5];

        // set some values
        theArray[0] = 5;
        theArray[1] = 3;
        theArray[2] = 8;
        theArray[4] = 7;

        // in memory our array now looks like:
        // [5, 3, 8, _, 7]

        // print out each value
        // one at a time method:
        System.out.print(theArray[0] + " " + theArray[1] + " " + "...");

        // For loop method
        System.out.print("\n\nFOR LOOP METHOD:\n[");
        for(int index = 0; index < theArray.length; index++)
        {
            System.out.print(theArray[index] + " ");
        }
        System.out.println("]");

        // for each loop method
        System.out.print("\n\nFOR EACH LOOP METHOD:\n[");
        for(int value : theArray) {
            System.out.print(value + " ");
        }
        System.out.println("]");

        // WITH INDICIES:
        // For loop method
        System.out.print("\n\nFOR LOOP METHOD:\n[");
        for(int index = 0; index < theArray.length; index++)
        {
            System.out.print(index + ": " + theArray[index] + ", ");
        }
        System.out.println("]");

        // for each loop method
        System.out.print("\n\nFOR EACH LOOP METHOD:\n[");
        int index2 = 0;
        for(int value : theArray) {
            System.out.print(index2 + ": " + value + ", ");
            index2++;
        }
        System.out.println("]");
    }
}
