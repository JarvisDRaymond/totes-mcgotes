package misc;

/**
 * Created by elly-luc on 6/29/17.
 */
public class Truncate {
    public static void main(String[] args) {

        doBadAverage();

        doGoodAverage();

    }

    public static void doBadAverage()
    {
        int val1 = 5;
        int val2 = 7;
        int val3 = 11;
        double average = (val1 + val2 + val3) / 3;
        System.out.println("Average (bad): " + average);

    }

    public static void doGoodAverage()
    {
        int val1 = 5;
        int val2 = 7;
        int val3 = 11;
        double average = ((double) (val1 + val2 + val3)) / 3;
        System.out.println("Average (good): " + average);
    }
}
