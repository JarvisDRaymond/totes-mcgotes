package misc;

// Validate user input steps:

// At any failure, reboot the loop

// 1) check if > 2 characters, (optional: apply trim() first)
// 2) check if first character is a-g
// 3) check if final character is 1-4

import java.util.List;
import java.util.ArrayList;

public class VendingDemo
{
    public static void main(String[] args) {

        List<String> samples = new ArrayList<>();
        samples.add("a1");
        samples.add("a5");
        samples.add("g1");
        samples.add("g5");
        samples.add("c3");
        samples.add("    c2   ");
        samples.add("a0"); // fail from here on
        samples.add("a6");
        samples.add("g0");
        samples.add("g6");
        samples.add("11"); // fail
        samples.add("98"); // fail
        samples.add("103"); // fail

        for (String s : samples) {
            System.out.print(s + ": ");
            if (isValidInput(s))
                System.out.println("Valid");
            else
                System.out.println("Invalid");
        }


        // if (! isValidInput("C3")) // C3 replace with keyboard.nextLine()
        // {
        //     System.out.println("Invalid input. Try again.");
        //     // @todo restart the loop
        //     // hint: continue
        // }
    }

    /**
     * checks if a user has entered valid input
     * being A1-A5 through G1-G5
     * @param  input the user input
     * @return       true if valid, else false
     */
    private static boolean isValidInput(String input)
    {
        // remove any whitespace from start or end of line and capitalize
        input = input.trim().toLowerCase();

        // Step 1: check if != 2 characters
        if (input.length() != 2)
            return false;

        // step 2: check if first character is a-g
//        char c1 = input.charAt(0);
//        boolean fail = false;
//        switch (c1) {
//            case 'a':
//            case 'b':
//            case 'c':
//            case 'd':
//            case 'e':
//            case 'f':
//            case 'g':
//                break;
//            default:
//                fail = true;
//                break;
//        }
//
//        if (fail)
//            return false;

        // step 2 alternative
        // convert c1 to an int,
        // @see https://www.cs.cmu.edu/~pattis/15-1XX/common/handouts/ascii.html
        int c1 = (int) input.charAt(0);
        if (c1 < 97 || c1 > 103)
            return false;

        // step 3: check if c2 is numbers 1-5
        int c2 = Integer.parseInt(input.substring(1));
        if (c2 < 1 || c2 > 5)
            return false;

        return true;
    }
}