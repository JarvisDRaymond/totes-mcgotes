package week4;

import java.util.Scanner;

/**
 * Listing 6.14
 */
public class DollarFormat
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        while(true) {
            System.out.println("Enter a positive or negative double: ");
            writeln(sc.nextDouble());
        }
    }

    /**
     Displays amount in dollars and cents notation.
     Rounds after two decimal places.
     Does not advance to the next line after output.
     */
    public static void write (double amount)
    {
        if (amount < 0)
        {
            amount = -amount;
            System.out.print ("-");
        }

        System.out.print ("$");
        writePositive (amount);
    }

    //Precondition: amount >= 0;
    //Displays amount in dollars and cents notation. Rounds
    //after two decimal places. Omits the dollar sign.
    private static void writePositive (double amount)
    {
        int allCents = (int) (Math.round (amount * 100));
        int dollars = allCents / 100;
        int cents = allCents % 100;
        System.out.print (dollars);
        System.out.print ('.');
        if (cents < 10)
            System.out.print ('0');
        System.out.print (cents);
    }

    /**
     Displays amount in dollars and cents notation.
     Rounds after two decimal places.
     Advances to the next line after output.
     */
    public static void writeln (double amount)
    {
        write (amount);
        System.out.println ();
    }
}
