package week4;

/**
 * Demonstrates calling static methods from non-static contexts, and vice versa
 */
public class SayHello1 {

    public static void main(String[] args)
    {
        // let's call printStatic()
        printStatic();

        // what will happen if we try calling printNonStatic()?
//        printNonStatic();

        // What if we try calling this.printNonStatic();
//        this.printNonStatic();

        // what about this.printStatic()?
//        this.printStatic();
//        SayHello1.printStatic();
//        SayHello1.printNonStatic();

        // What if we create an object of SayHello1?
        SayHello1 theProgram = new SayHello1();

        // Now let's call printNonStatic()
        theProgram.printNonStatic();
    }

    public static void printStatic()
    {
        System.out.println("We are in a static method, calling from a static context");
    }

    public void printNonStatic()
    {
        System.out.println("Non-static method called. Hello!");
    }
}
