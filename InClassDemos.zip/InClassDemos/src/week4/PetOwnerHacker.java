package week4;

/**
 * Created by elly-luc on 6/29/17.
 */
public class PetOwnerHacker {
    public static void main(String[] args) {

        PetOwner elly = new PetOwner(new Pet("Seabiscuit", 4, 11.5));
        Pet seabiscuit = elly.getPet();

        System.out.println("Elly's pet's information:");
        seabiscuit.writeOutput();

        // now let's hack Sebastian
        seabiscuit.setPet("Surprise I'm a big dog", 12, 83.2);
        System.out.println("\nHacked Sebastian to:");
        seabiscuit.writeOutput();

        // but it wasn't just this version of Sebastian changed
        // look at the copy stored in the pet owner!
        System.out.println("\nElly's private copy of Sebastian:");
        elly.getPet().writeOutput();
    }
}
