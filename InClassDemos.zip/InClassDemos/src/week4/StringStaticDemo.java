package week4;

/**
 * Alternative to Listing 6.7 & 6.8
 */
public class StringStaticDemo {
    public static void main (String[] args) {

        // Refer to a static method
        boolean b = false; // 0
        System.out.println("b as a string is " + String.valueOf(b));

        // now let's convert b to a String in the same way, but return the value of it
        String boolString = String.valueOf(b);

        // make the string uppercase - good example
        System.out.println("\nb as an uppercase string is " + boolString.toUpperCase());

        // make the string uppercase - bad example (does not compile)
        // non-static method cannot be referenced from a static example
//        System.out.println("\nb as an uppercase string is " + String.toUpperCase(b));

    }
}
