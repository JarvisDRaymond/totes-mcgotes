package week4;

/**
 * Demonstrates instance vs class variables
 */
public class SayHello2 {

    public static String classVarEx = "This is a class variable";
    public        String instanceVarEx = "This is an instance variable";

    public static void main(String[] args)
    {
        // let's print our class variable
        System.out.println(classVarEx);

        // let's print out our instance variable
//        System.out.println(instanceVarEx);

        // What if we create an object of SayHello2?
        SayHello2 anObject = new SayHello2();

        // Now let's print out the instance variables
        System.out.println(anObject.instanceVarEx);

        // Let's print out the class variable again
        System.out.println(SayHello2.classVarEx);

        System.out.println(anObject.classVarEx);
    }
}