package week4;

/**
 * Replaces listing 6.18
 */
public class PetOwner {
    private Pet thePet;

    public PetOwner(Pet thePet)
    {
        this.thePet = thePet;
    }

    public Pet getPet()
    {
        return thePet;
    }
}
