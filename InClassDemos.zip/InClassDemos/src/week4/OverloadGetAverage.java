package week4;

/**
 * Listing 6.15
 This class illustrates overloading.
 */
public class OverloadGetAverage
{
    public static void main (String [] args)
    {
        double average1 = OverloadGetAverage.getAverage (40.0, 50.0);
        double average2 = OverloadGetAverage.getAverage (1.0, 2.0, 3.0);
//        double average3 = OverloadGetAverage.getAverage (-36.3, 2.7, 178.39, -8.2);
        char average4 = OverloadGetAverage.getAverage ('a', 'c');
        System.out.println ("average1 = " + average1);
        System.out.println ("average2 = " + average2);
//        System.out.println ("average3 = " + average3);
        System.out.println ("average4 = " + average4);
    }


    public static double getAverage (double first, double second)
    {

        return (first + second) / 2.0;
    }

    public static double getAverage (double first, double second,
                                     double third)
    {
        return (first + second + third) / 3.0;
    }

//    public static double getAverage(double ...values) {
//        int numValues = 0;
//        double total = 0;
//        for (double d : values) {
//            total += d;
//            numValues++;
//        }
//
//        return total / numValues;
//    }


    public static char getAverage (char first, char second)
    {
        return (char) (((int) first + (int) second) / 2);
    }
}
