package week4;

/**
 * Modified listing 6.2 7th ed
 */
import java.util.Scanner;
public class PetDemo
{
    public static void main (String [] args)
    {
        Pet p0 = new Pet ();
        Pet p1 = new Pet ("Spot");
        Pet p2 = new Pet ("Queen Fuzzyboots", 5, 10.3);

        System.out.println("P0:");
        p0.writeOutput();

        System.out.println("\nP1:");
        p1.writeOutput();

        System.out.println("\nP2:");
        p2.writeOutput();
    }
}